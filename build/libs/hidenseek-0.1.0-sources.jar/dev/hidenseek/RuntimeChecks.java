package dev.hidenseek;
import dev.hidenseek.core.*;
import dev.hidenseek.core.Geometry.Point;
import com.mojang.authlib.GameProfile;
import java.util.*;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_5454;
import net.minecraft.class_8791;

/** Opt-in headless integration checks, on an isolated server. Not a multiplayer playtest. */
public final class RuntimeChecks {
 public static void run(StillHunt mod){
  if(mod.match.active())throw new IllegalStateException("Smoke checks need an inactive isolated world");
  Match old=mod.match;
  try{
   var world=mod.server.method_30002();UUID h=UUID.randomUUID(),a=UUID.randomUUID(),b=UUID.randomUUID();
   var player=new class_3222(mod.server,world,new GameProfile(h,"SmokeHider"),class_8791.method_53821());
   player.method_5814(8,80,8);mod.match=new Match();mod.match.start(h,List.of(a,b),new Point(0,80,0),-512,-512,"minecraft:overworld",mod.rules);mod.match.lock(new Point(8,80,8));
   class_243 initial=player.method_19538();player.method_5814(25,90,25);check(player.method_19538().equals(initial),"setPosition lock");
   player.method_5784(class_1313.field_6310,new class_243(1,1,1));check(player.method_19538().equals(initial),"piston movement lock");
   player.method_18799(new class_243(5,5,5));check(player.method_18798().equals(class_243.field_1353),"velocity lock");
   var result=player.method_61275(new class_5454(world,new class_243(40,80,40),class_243.field_1353,0,0,class_5454.field_52245));check(result==null&&player.method_19538().equals(initial),"teleport lock");
   check(!player.method_5810(),"unpushable body");
   check(!player.method_64397(world,world.method_48963().method_48830(),100),"environment damage denied");
   mod.match.pause();player.method_5814(50,80,50);check(player.method_19538().equals(initial),"pause retains anchor");
   String serialized=Storage.JSON.toJson(mod.match);Match restored=Storage.JSON.fromJson(serialized,Match.class);check(restored.hide.equals(mod.match.hide)&&restored.phase==Match.Phase.PAUSED,"save round-trip");
   mod.match.finish("admin");player.method_5814(12,80,12);check(player.method_23317()==12,"end releases anchor");
   StillHunt.LOG.info("STILLHUNT_SMOKE_PASS: 9 runtime checks; no real clients used");
  }finally{mod.match=old;}
 }
 private static void check(boolean pass,String label){if(!pass)throw new AssertionError("Runtime smoke failed: "+label);}
}
