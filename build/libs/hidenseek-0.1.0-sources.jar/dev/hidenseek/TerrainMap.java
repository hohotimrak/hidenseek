package dev.hidenseek;
import dev.hidenseek.core.*;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3218;

public final class TerrainMap {
 private int cursor;
 public record Tile(int x,int z,int height,int color,String biome) {}
 public List<Tile> sample(class_3218 world,Match match,Rules rules){
  int side=rules.arenaSize/rules.cellSize;List<Tile> out=new ArrayList<>();
  for(int i=0;i<16;i++){
   int index=cursor++%(side*side),x=match.originX+(index%side)*rules.cellSize,z=match.originZ+(index/side)*rules.cellSize;
   if(!world.method_22340(new class_2338(x,0,z)))continue;
   int y=world.method_8624(class_2902.class_2903.field_13202,x,z)-1;class_2338 pos=new class_2338(x,y,z);
   int rgb=world.method_8320(pos).method_26205(world,pos).field_16011;
   out.add(new Tile(x,z,y,0xff000000|rgb,world.method_23753(pos).method_40230().map(k->k.method_29177().toString()).orElse("unknown")));
  }return out;
 }
}
