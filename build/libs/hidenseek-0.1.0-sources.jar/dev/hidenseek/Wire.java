package dev.hidenseek;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class Wire {
 private Wire(){}
 public record ImagePart(String match,String request,int index,int total,byte[] data) implements class_8710 {
  public static final class_9154<ImagePart> ID=new class_9154<>(class_2960.method_60655("hidenseek","image"));
  public static final class_9139<class_9129,ImagePart> CODEC=class_9139.method_56438((p,b)->{b.method_10788(p.match,64);b.method_10788(p.request,64);b.method_10804(p.index);b.method_10804(p.total);b.method_10813(p.data);},b->new ImagePart(b.method_10800(64),b.method_10800(64),b.method_10816(),b.method_10816(),b.method_10803(16000)));
  public class_9154<? extends class_8710> method_56479(){return ID;}
 }
 public record Tiles(String json) implements class_8710 {
  public static final class_9154<Tiles> ID=new class_9154<>(class_2960.method_60655("hidenseek","tiles"));
  public static final class_9139<class_9129,Tiles> CODEC=class_9139.method_56438((p,b)->b.method_10788(p.json,32000),b->new Tiles(b.method_10800(32000)));
  public class_9154<? extends class_8710> method_56479(){return ID;}
 }
 public record Intent(String json) implements class_8710 {
  public static final class_9154<Intent> ID=new class_9154<>(class_2960.method_60655("hidenseek","intent"));
  public static final class_9139<class_9129,Intent> CODEC=class_9139.method_56438((p,b)->b.method_10788(p.json,4096),b->new Intent(b.method_10800(4096)));
  public class_9154<? extends class_8710> method_56479(){return ID;}
 }
 public record View(String json) implements class_8710 {
  public static final class_9154<View> ID=new class_9154<>(class_2960.method_60655("hidenseek","view"));
  public static final class_9139<class_9129,View> CODEC=class_9139.method_56438((p,b)->b.method_10788(p.json,250000),b->new View(b.method_10800(250000)));
  public class_9154<? extends class_8710> method_56479(){return ID;}
 }
}
