package dev.hidenseek.client;
import dev.hidenseek.Storage;
import dev.hidenseek.core.*;
import dev.hidenseek.core.Geometry.*;
import com.google.gson.*;
import java.util.*;
import net.minecraft.class_310;
import net.minecraft.class_318;

/** Opt-in rendering fixtures. These are explicitly NOT network/playtest evidence. */
public final class ClientUiCheck {
 private static int ticks,stage=-1;private static boolean saving;private static Match fixture;private static Rules rules;private static UUID h,s;
 public static void tick(class_310 client){
  if(stage<0){if(client.method_18506()!=null||++ticks<100)return;
   rules=new Rules();h=UUID.randomUUID();s=UUID.randomUUID();fixture=new Match();fixture.start(h,List.of(s,UUID.randomUUID()),new Point(0,64,0),-512,-512,"minecraft:overworld",rules);fixture.lock(new Point(100,64,0));fixture.constraints.add(new Constraint("fixture_east","east",0,0,0,0,true,0));fixture.reward(3,rules);show(client,0);return;
  }
  if(saving||++ticks<60)return;saving=true;
  class_318.method_22690(client.field_1697,"stillhunt-ui-"+stage+".png",client.method_1522(),1,text->client.execute(()->{
   if(stage>=3){System.out.println("STILLHUNT_UI_FIXTURES_COMPLETE: rendered 4 panels, no gameplay asserted");client.method_1592();}
   else{show(client,stage+1);saving=false;}
  }));
 }
 private static void show(class_310 client,int next){stage=next;ticks=0;HuntClient.view=Storage.JSON.toJsonTree(fixture.view(next>=2?h:s,rules)).getAsJsonObject();client.method_1507(new HuntScreen(next));}
}
