package dev.hidenseek.client;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
public class ImageScreen extends class_437 {
 public ImageScreen(){super(class_2561.method_43471("hint.hidenseek.screenshot"));}
 public boolean method_25421(){return false;}
 protected void method_25426(){method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"),b->method_25419()).method_46434(field_22789/2-40,field_22790-30,80,20).method_46431());}
 public void method_25394(class_332 ctx,int mx,int my,float delta){ctx.method_25294(0,0,field_22789,field_22790,0xff101820);ctx.method_27534(field_22793,field_22785,field_22789/2,12,0xffffffff);if(ImageCapture.image!=null){int w=Math.min(field_22789-24,(field_22790-70)*16/9),h=w*9/16;ctx.method_25302(class_10799.field_56883,ImageCapture.image,(field_22789-w)/2,32,0,0,w,h,320,180,320,180);}super.method_25394(ctx,mx,my,delta);}
}
