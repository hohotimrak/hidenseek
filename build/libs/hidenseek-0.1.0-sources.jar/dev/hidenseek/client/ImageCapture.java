package dev.hidenseek.client;
import dev.hidenseek.Wire;
import dev.hidenseek.core.ImageTransfer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_437;
import java.util.*;

public final class ImageCapture {
 private static String request="",completed="";
 private static int frames;
 private static long readyAt;
 private static boolean oldHud;
 private static class_437 oldScreen;
 public static class_2960 image;
 private static ImageTransfer incoming;
 private static String incomingId="";
 public static void tick(class_310 client){
  String next=HuntClient.string(HuntClient.view,"imageRequest","");
  if(!next.isEmpty()&&!next.equals(completed)&&request.isEmpty()&&client.field_1724!=null){
   request=next;oldHud=client.field_1690.field_1842;oldScreen=client.field_1755;
   client.method_1507(null);client.field_1690.field_1842=true;client.method_1504(client.field_1724);
   // Allow body chunks and rendering to settle before capture.
   frames=1;readyAt=System.nanoTime()+3_000_000_000L;
  }
 }
 public static void rendered(){
  if(request.isEmpty())return;var client=class_310.method_1551();
  if(client.field_1724==null||!HuntClient.view.has("imageRequest")){restore(client);return;}
  client.method_1504(client.field_1724);client.field_1690.field_1842=true;
  if(System.nanoTime()<readyAt||--frames>0)return;String id=request,match=HuntClient.string(HuntClient.view,"id","");completed=id;
  class_318.method_1663(client.method_1522(),full->{
   try(full;var small=new class_1011(ImageTransfer.WIDTH,ImageTransfer.HEIGHT,false)){
    full.method_4300(0,0,full.method_4307(),full.method_4323(),small);byte[] rgb=new byte[ImageTransfer.LENGTH];
    for(int y=0;y<ImageTransfer.HEIGHT;y++)for(int x=0;x<ImageTransfer.WIDTH;x++){int color=small.method_61940(x,y),offset=(y*ImageTransfer.WIDTH+x)*3;rgb[offset]=(byte)(color>>16);rgb[offset+1]=(byte)(color>>8);rgb[offset+2]=(byte)color;}
    client.execute(()->{if(!match.equals(HuntClient.string(HuntClient.view,"id","")))return;for(int i=0;i<ImageTransfer.COUNT;i++)ClientPlayNetworking.send(new Wire.ImagePart(match,id,i,ImageTransfer.COUNT,Arrays.copyOfRange(rgb,i*ImageTransfer.CHUNK,Math.min(rgb.length,(i+1)*ImageTransfer.CHUNK))));});
   }
  });
  restore(client);
 }
 private static void restore(class_310 client){client.field_1690.field_1842=oldHud;if(client.field_1724!=null)client.method_1507(oldScreen);oldScreen=null;request="";}
 public static void receive(Wire.ImagePart part){
  if(!part.match().equals(HuntClient.string(HuntClient.view,"id","")))return;
  if(!part.request().equals(incomingId)){incomingId=part.request();incoming=new ImageTransfer();}
  if(incoming.accept(part.index(),part.total(),part.data())){
   byte[] rgb=incoming.bytes();var pixels=new class_1011(ImageTransfer.WIDTH,ImageTransfer.HEIGHT,false);
   for(int y=0;y<ImageTransfer.HEIGHT;y++)for(int x=0;x<ImageTransfer.WIDTH;x++){int o=(y*ImageTransfer.WIDTH+x)*3;pixels.method_61941(x,y,0xff000000|(rgb[o]&255)<<16|(rgb[o+1]&255)<<8|(rgb[o+2]&255));}
   var client=class_310.method_1551();if(image!=null)client.method_1531().method_4615(image);
   image=class_2960.method_60655("hidenseek","latest_image");client.method_1531().method_4616(image,new class_1043(()->"Still Hunt clue",pixels));
   client.method_1507(new ImageScreen());incoming=null;incomingId="";
  }
 }
 public static void clear(){var client=class_310.method_1551();if(!request.isEmpty())restore(client);if(image!=null)client.method_1531().method_4615(image);image=null;incoming=null;completed="";}
}
