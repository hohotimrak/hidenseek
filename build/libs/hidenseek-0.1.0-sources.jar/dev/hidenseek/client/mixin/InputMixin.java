package dev.hidenseek.client.mixin;
import dev.hidenseek.client.HuntClient;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_743.class)
public abstract class InputMixin extends class_744 {
 @Inject(method="tick",at=@At("RETURN"))
 private void restrict(CallbackInfo ci){
  if(HuntClient.frozen()){field_54155=class_10185.field_54098;field_55868=class_241.field_1340;return;}
  var player=class_310.method_1551().field_1724;
  boolean allowSwim=player!=null&&(player.method_5799()||player.method_6101());
  var p=field_54155;field_54155=new class_10185(p.comp_3159(),p.comp_3160(),p.comp_3161(),p.comp_3162(),p.comp_3163()&&(!HuntClient.effect("boots")||allowSwim),p.comp_3164(),p.comp_3165()&&!HuntClient.effect("rhythm"));
 }
}
