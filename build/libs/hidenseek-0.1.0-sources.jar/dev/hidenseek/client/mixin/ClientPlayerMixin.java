package dev.hidenseek.client.mixin;
import dev.hidenseek.client.HuntClient;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_746.class)
public abstract class ClientPlayerMixin {
 @Inject(method="move",at=@At("HEAD"),cancellable=true)
 private void frozen(class_1313 type,class_243 movement,CallbackInfo ci){if(HuntClient.frozen())ci.cancel();}
}
