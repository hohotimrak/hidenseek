package dev.hidenseek.client.mixin;
import dev.hidenseek.client.HuntClient;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(class_1309.class)
public abstract class ClientLivingMixin {
 @Inject(method="canGlide",at=@At("HEAD"),cancellable=true)
 private void wings(CallbackInfoReturnable<Boolean> ci){if((Object)this==class_310.method_1551().field_1724&&HuntClient.effect("flight"))ci.setReturnValue(true);}
}
