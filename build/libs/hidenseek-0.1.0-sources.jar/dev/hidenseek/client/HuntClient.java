package dev.hidenseek.client;

import com.google.gson.*;
import dev.hidenseek.Wire;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.*;
import net.minecraft.class_243;
import net.minecraft.class_745;
import com.mojang.authlib.GameProfile;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class HuntClient implements ClientModInitializer {
 public static JsonObject view=new JsonObject();
 public static class_243 anchor;
 public static final Map<String,JsonObject> terrain=new HashMap<>();
 private boolean pressed;
 private class_745 camera;
 public void onInitializeClient(){
  ClientPlayNetworking.registerGlobalReceiver(Wire.View.ID,(payload,ctx)->ctx.client().execute(()->{
   String old=string(view,"phase",""),oldId=string(view,"id","");view=JsonParser.parseString(payload.json()).getAsJsonObject();if(!oldId.equals(string(view,"id","")))terrain.clear();
   if(view.has("anchor")){var a=view.getAsJsonObject("anchor");anchor=new class_243(number(a,"x",0),number(a,"y",0),number(a,"z",0));}
   if(string(view,"phase","").equals("FINISHED")&&!old.equals("FINISHED")){ImageCapture.clear();anchor=null;}
  }));
  ClientPlayNetworking.registerGlobalReceiver(Wire.Tiles.ID,(payload,ctx)->ctx.client().execute(()->{var data=JsonParser.parseString(payload.json()).getAsJsonObject();if(!string(data,"match","").equals(string(view,"id","")))return;for(var t:data.getAsJsonArray("tiles")){var tile=t.getAsJsonObject();terrain.put(tile.get("x").getAsInt()+":"+tile.get("z").getAsInt(),tile);}}));
  ClientPlayNetworking.registerGlobalReceiver(Wire.ImagePart.ID,(payload,ctx)->ctx.client().execute(()->ImageCapture.receive(payload)));
  ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->{ImageCapture.clear();view=new JsonObject();anchor=null;camera=null;terrain.clear();});
  ClientTickEvents.END_CLIENT_TICK.register(client->{
   if(Boolean.getBoolean("stillhunt.uiCheck"))ClientUiCheck.tick(client);
   if(client.field_1724==null||client.field_1687==null)return;
   ImageCapture.tick(client);
   boolean down=GLFW.glfwGetKey(client.method_22683().method_4490(),GLFW.GLFW_KEY_H)==GLFW.GLFW_PRESS;
   if(down&&!pressed&&client.field_1755==null&&view.has("role"))client.method_1507(new HuntScreen());pressed=down;
   String phase=string(view,"phase","");boolean active=phase.equals("SEEKING")||phase.equals("PAUSED");
   if(active&&string(view,"role","").equals("hider")&&anchor!=null){client.field_1724.method_18799(class_243.field_1353);client.field_1724.method_33574(anchor);}
   if(active&&view.has("camera")){
    String target=view.get("camera").getAsString();JsonObject pose=null;
    for(var value:view.getAsJsonArray("positions"))if(value.getAsJsonObject().get("id").getAsString().equals(target))pose=value.getAsJsonObject();
    if(pose!=null){
     if(camera==null)camera=new class_745(client.field_1687,new GameProfile(UUID.randomUUID(),"StillHuntCamera"));
     camera.method_5808(pose.get("x").getAsDouble(),pose.get("y").getAsDouble(),pose.get("z").getAsDouble(),pose.get("yaw").getAsFloat(),pose.get("pitch").getAsFloat());
     camera.method_5847(camera.method_36454());client.method_1504(camera);
    }
   }else if(camera!=null){client.method_1504(client.field_1724);camera=null;}
  });
 }
 public static boolean frozen(){return anchor!=null&&string(view,"role","").equals("hider")&&Set.of("SEEKING","PAUSED").contains(string(view,"phase",""));}
 public static boolean effect(String id){return view.has("participant")&&view.getAsJsonObject("participant").getAsJsonObject("effects").has(id)&&view.getAsJsonObject("participant").getAsJsonObject("effects").get(id).getAsLong()>number(view,"tick",0);}
 public static String string(JsonObject o,String key,String fallback){return o.has(key)?o.get(key).getAsString():fallback;}
 public static double number(JsonObject o,String key,double fallback){return o.has(key)?o.get(key).getAsDouble():fallback;}
 public static void intent(JsonObject o){if(!view.has("id"))return;o.addProperty("match",view.get("id").getAsString());ClientPlayNetworking.send(new Wire.Intent(o.toString()));}
 public static JsonObject action(String action){var o=new JsonObject();o.addProperty("action",action);return o;}
}
