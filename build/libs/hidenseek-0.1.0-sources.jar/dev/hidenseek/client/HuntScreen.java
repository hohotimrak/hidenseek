package dev.hidenseek.client;

import com.google.gson.*;
import dev.hidenseek.core.Geometry.*;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.widget.*;
import java.util.*;
import static dev.hidenseek.client.HuntClient.*;

public class HuntScreen extends class_437 {
 private int tab=0,hintIndex=0,targetIndex=0,layer=-65,replacement=-1;
 private double zoom=1,panX,panZ;
 private int scroll;
 private JsonObject preview;
 private String lastDynamic="";
 private class_342 param,label;
 private String parameterValue;
 private final List<String> hints=List.of("animal","block","biome","east","south","above","sector","circle","rectangle","distance","firework","screenshot","bearing","biome_is","structure");
 public HuntScreen(){super(class_2561.method_43471("hunt.title"));}
 public HuntScreen(int initialTab){this();tab=initialTab;}
 public boolean method_25421(){return false;}
 public void method_25393(){String dynamic=string(view,"phase","")+view.get("hand")+view.get("offer");if(!dynamic.equals(lastDynamic)){lastDynamic=dynamic;if(tab==2||tab==3)method_25426();}}
 private void button(int x,int y,int w,String key,Runnable action){method_37063(class_4185.method_46430(class_2561.method_43471(key),b->action.run()).method_46434(x,y,w,20).method_46431());}
 private void cardButton(int x,int y,int w,JsonObject card,Runnable action){String id=card.get("kind").getAsString();class_2561 name=class_2561.method_43471("card.hidenseek."+id);if(view.has("cardDefinitions")&&view.getAsJsonObject("cardDefinitions").has(id)){var definition=view.getAsJsonObject("cardDefinitions").getAsJsonObject(id);var names=definition.getAsJsonObject("names");name=class_2561.method_43470(string(names,field_22787.field_1690.field_1883,string(names,"en_us",id))+" · "+definition.get("durationSeconds").getAsInt()+"s");}method_37063(class_4185.method_46430(name,b->action.run()).method_46434(x,y,w,20).method_46431());}
 private void changeTab(int next){if(param!=null)parameterValue=param.method_1882();tab=next;scroll=0;method_25426();}
 protected void method_25426(){
  method_37067();int y=38;
  button(12,y,90,"hunt.map",()->changeTab(0));button(106,y,90,"hunt.hints",()->changeTab(1));button(200,y,90,"hunt.cards",()->changeTab(2));button(294,y,90,"hunt.kits",()->changeTab(3));
  button(field_22789-86,10,74,"gui.done",this::method_25419);
  if(tab==0){button(field_22789-100,68,88,"hunt.layer",()->{layer=layer< -64?-64:layer>=304?-65:layer+16;});button(field_22789-100,92,88,"hunt.reset",()->{zoom=1;panX=panZ=0;});
   label=new class_342(field_22793,field_22789-130,122,118,20,class_2561.method_43471("hunt.mark"));label.method_1880(32);label.method_1852("?");method_37063(label);
  }
  if(tab==1){
   button(12,68,34,"<",()->{hintIndex=Math.floorMod(hintIndex-1,hints.size());preview=null;parameterValue=null;method_25426();});button(300,68,34,">",()->{hintIndex=(hintIndex+1)%hints.size();preview=null;parameterValue=null;method_25426();});
   param=new class_342(field_22793,12,118,Math.min(field_22789-24,380),20,class_2561.method_43471("hunt.parameters"));param.method_1880(200);param.method_1852(parameterValue==null?defaultParam():parameterValue);method_37063(param);
   button(12,145,132,"hunt.preview",()->{preview=makeHint();if(preview!=null){var quote=preview.deepCopy();quote.addProperty("action","quote");intent(quote);}});
   button(150,145,132,"hunt.buy",()->{if(preview!=null&&view.has("quote")&&string(view.getAsJsonObject("quote"),"kind","").equals(string(preview,"kind",""))){preview.addProperty("quotedTier",view.getAsJsonObject("quote").get("tier").getAsInt());preview.addProperty("request",UUID.randomUUID().toString());intent(preview);preview=null;}});
   button(12,218,260,"hunt.challenge",()->intent(action("challenge")));
   button(12,244,260,"hunt.antidote",()->intent(action("antidote")));
   button(278,244,140,"hunt.wings",()->intent(action("wings")));
  }
  if(tab==2){
   button(12,68,200,"hunt.next_target",()->{targetIndex++;});
   button(220,68,100,"hunt.watch",()->{JsonObject o=action("camera");o.addProperty("target",target());intent(o);});
   button(326,68,100,"hunt.return",()->{intent(action("camera"));});
   if(view.has("hand")){int i=0;for(var e:view.getAsJsonArray("hand")){var card=e.getAsJsonObject();int row=i++;cardButton(12,120+row*23,260,card,()->{var o=action("card");o.addProperty("card",card.get("id").getAsString());o.addProperty("target",target());intent(o);});}}
   if(view.has("offer")){int i=0;for(var e:view.getAsJsonArray("offer")){int index=i++;var card=e.getAsJsonObject();cardButton(290,120+index*25,Math.max(110,field_22789-302),card,()->{var o=action("choose");o.addProperty("index",index);o.addProperty("offer",string(view,"offerId",""));o.addProperty("replace",replacement);intent(o);});}button(290,230,Math.max(110,field_22789-302),"hunt.replace",()->{replacement++;if(replacement>=view.getAsJsonArray("hand").size())replacement=-1;});}
  }
  if(tab==3&&view.has("participant")){int i=0;for(var k:view.getAsJsonObject("participant").getAsJsonArray("kits")){String kit=k.getAsString();button(12,90+i++*28,260,"kit.hidenseek."+kit,()->{var o=action("kit");o.addProperty("kit",kit);intent(o);});}button(12,222,260,"hunt.kit_power",()->intent(action("kit_power")));}
 }
 private String target(){if(!view.has("seekers")||view.getAsJsonArray("seekers").isEmpty())return "";return view.getAsJsonArray("seekers").get(Math.floorMod(targetIndex,view.getAsJsonArray("seekers").size())).getAsString();}
 private String defaultParam(){int x=(int)number(view,"originX",0),z=(int)number(view,"originZ",0);return switch(hints.get(hintIndex)){case "block"->"minecraft:stone";case "biome_is"->"minecraft:plains";case "above"->"64";case "circle"->(x+256)+" "+(z+256)+" 128";case "rectangle","sector"->x+" "+z+" "+(x+128)+" "+(z+128);case "distance"->"128";default->"";};}
 private JsonObject makeHint(){try{
  var o=action("hint");String k=hints.get(hintIndex);o.addProperty("kind",k);String[] p=param.method_1882().trim().split("\\s+");
  switch(k){case "block"->o.addProperty("block",param.method_1882().trim());case "biome_is"->o.addProperty("biome",param.method_1882().trim());case "above"->o.addProperty("y",Double.parseDouble(p[0]));case "distance"->o.addProperty("radius",Double.parseDouble(p[0]));case "circle","rectangle","sector"->{o.addProperty("x",Double.parseDouble(p[0]));o.addProperty("z",Double.parseDouble(p[1]));if(k.equals("circle"))o.addProperty("radius",Double.parseDouble(p[2]));else{o.addProperty("x2",Double.parseDouble(p[2]));o.addProperty("z2",Double.parseDouble(p[3]));}}}
  return o;
 }catch(RuntimeException ex){return null;}}
 public void method_25394(class_332 ctx,int mx,int my,float delta){
  ctx.method_25294(0,0,field_22789,field_22790,0xee101820);ctx.method_27535(field_22793,field_22785,12,12,0xffe2b75a);
  String seconds=String.format(Locale.ROOT,"%02d:%02d",(int)number(view,"seconds",0)/60,(int)number(view,"seconds",0)%60);
  ctx.method_27535(field_22793,class_2561.method_43470(string(view,"phase","")+" • "+seconds+" • "+(view.has("intel")?"◆ "+view.get("intel").getAsInt():string(view,"role",""))),140,15,0xffeeeeee);
  if(tab!=0){ctx.method_44379(0,64,field_22789,field_22790-15);ctx.method_51448().pushMatrix();ctx.method_51448().translate(0,-scroll);}
  if(tab==0)renderMap(ctx,mx,my);
  if(tab==1){
   String k=hints.get(hintIndex);ctx.method_27535(field_22793,class_2561.method_43471("hint.hidenseek."+k),54,75,0xffffffff);
   int tier=view.has("tiers")&&view.getAsJsonObject("tiers").has(k)?view.getAsJsonObject("tiers").get(k).getAsInt():0;
   if(preview!=null&&view.has("quote")&&string(view.getAsJsonObject("quote"),"kind","").equals(k))tier=view.getAsJsonObject("quote").get("tier").getAsInt();
   ctx.method_25303(field_22793,"☠".repeat(tier)+"  ◆ "+(tier>0?view.getAsJsonArray("costs").get(tier-1).getAsInt():0),12,98,0xffe2b75a);
   if(preview!=null)ctx.method_27535(field_22793,class_2561.method_43469("hunt.preview_ready",param.method_1882()),12,176,0xff88eeaa);
   ctx.method_27535(field_22793,class_2561.method_43471("hunt.parameter_help"),12,193,0xffaab8c5);
   if(view.has("history")){int y=278;var history=view.getAsJsonArray("history");for(int i=history.size()-1;i>=0;i--){var h=history.get(i).getAsJsonObject();ctx.method_27535(field_22793,class_2561.method_43471("hint.hidenseek."+h.get("kind").getAsString()).method_27693(": "+h.get("answer").getAsString()),12,y,0xffcccccc);y+=13;}}
  }
  if(tab==2){String targetName=target();if(view.has("positions"))for(var e:view.getAsJsonArray("positions")){var p=e.getAsJsonObject();if(string(p,"id","").equals(targetName)){targetName=string(p,"name",targetName);break;}}ctx.method_27535(field_22793,class_2561.method_43470(targetName),12,98,0xffaab8c5);ctx.method_65179(field_22793,class_2561.method_43471("hunt.offer_note"),12,305,field_22789-24,0xffaab8c5);ctx.method_25303(field_22793,"↔ "+(replacement+1),290,255,0xffe2b75a);}
  if(tab==3&&view.has("participant"))ctx.method_27535(field_22793,class_2561.method_43469("hunt.selected",string(view.getAsJsonObject("participant"),"kit","")),12,200,0xffaab8c5);
  if(tab==0&&view.has("participant")){var p=view.getAsJsonObject("participant");int y=198;long now=(long)number(view,"tick",0);for(var effect:p.getAsJsonObject("effects").entrySet()){long left=(effect.getValue().getAsLong()-now)/20;if(left>0&&y<field_22790-16){ctx.method_25303(field_22793,effect.getKey()+": "+left+"s",field_22789-145,y,0xffe2b75a);y+=12;}}if(!string(p,"taskId","").isEmpty())ctx.method_25303(field_22793,string(p,"taskId","")+": "+(int)number(p,"taskProgress",0),field_22789-145,y,0xff88dddd);}
  for(var child:method_25396())if(child instanceof class_339 widget&&widget.method_46427()>=64)widget.method_25394(ctx,mx,my+scroll,delta);
  if(tab!=0){ctx.method_51448().popMatrix();ctx.method_44380();ctx.method_27535(field_22793,class_2561.method_43471("hunt.scroll"),12,field_22790-12,0xffaab8c5);}
  for(var child:method_25396())if(child instanceof class_339 widget&&widget.method_46427()<64)widget.method_25394(ctx,mx,my,delta);
 }
 private int mapSide(){return Math.max(64,Math.min(field_22789-160,field_22790-120));}
 private double scale(){return mapSide()/number(view,"size",1024)*zoom;}
 private int sx(double x){return (int)(12+(x-number(view,"originX",0))*scale()+panX);}
 private int sz(double z){return (int)(68+(z-number(view,"originZ",0))*scale()+panZ);}
 private void renderMap(class_332 ctx,int mx,int my){
  if(!view.has("size"))return;int side=mapSide();ctx.method_44379(12,68,12+side,68+side);
  int originX=(int)number(view,"originX",0),originZ=(int)number(view,"originZ",0),size=(int)number(view,"size",1024),cell=(int)number(view,"cell",16);
  List<Constraint> constraints=new ArrayList<>();if(view.has("constraints"))for(var e:view.getAsJsonArray("constraints"))constraints.add(new Gson().fromJson(e,Constraint.class));
  for(int x=originX;x<originX+size;x+=cell)for(int z=originZ;z<originZ+size;z+=cell){
   double lo=layer< -64?number(view,"minY",-64):layer,hi=layer< -64?number(view,"maxY",320):layer+16;
   Box box=new Box(x,lo,z,x+cell,hi,z+cell);String reason="";
   for(var c:constraints)if(c.excludes(box)){reason=c.kind();break;}
   boolean excluded=!reason.isEmpty();var tile=terrain.get(x+":"+z);int color=excluded?0xff622f3c:tile!=null?tile.get("color").getAsInt():((x/cell+z/cell)%2==0?0xff354b57:0xff304550);
   ctx.method_25294(sx(x),sz(z),sx(x+cell),sz(z+cell),color);
   if(excluded){ctx.method_25294(sx(x),sz(z),sx(x)+1,sz(z+cell),0xff994555);}
   if(mx>=sx(x)&&mx<sx(x+cell)&&my>=sz(z)&&my<sz(z+cell)&&!reason.isEmpty())hoverReason=reason;
  }
  if(preview!=null&&Set.of("circle","rectangle","sector").contains(string(preview,"kind",""))){
   double a=number(preview,"x",0),b=number(preview,"z",0);if(preview.has("radius")){double r=number(preview,"radius",128);for(int i=0;i<120;i++){double t=i*Math.PI/60;ctx.method_25294(sx(a+Math.cos(t)*r),sz(b+Math.sin(t)*r),sx(a+Math.cos(t)*r)+2,sz(b+Math.sin(t)*r)+2,0xffffff44);}}
   else{int left=sx(a),top=sz(b),right=sx(number(preview,"x2",a)),bottom=sz(number(preview,"z2",b));ctx.method_49601(left,top,right-left,bottom-top,0xffffff44);}
  }
  if(view.has("marks"))for(var e:view.getAsJsonArray("marks")){var m=e.getAsJsonObject();int x=sx(number(m,"x",0)),z=sz(number(m,"z",0));ctx.method_25303(field_22793,"◇"+string(m,"label",""),x,z,0xffffcc55);}
  if(view.has("positions"))for(var e:view.getAsJsonArray("positions")){var p=e.getAsJsonObject();ctx.method_25294(sx(number(p,"x",0))-2,sz(number(p,"z",0))-2,sx(number(p,"x",0))+3,sz(number(p,"z",0))+3,0xff6de4df);}
  ctx.method_44380();ctx.method_65179(field_22793,class_2561.method_43471("hunt.map_legend"),12,78+side,field_22789-24,0xffaab8c5);
  ctx.method_25303(field_22793,layer< -64?"Y: ALL":"Y: "+layer+"…"+(layer+16),field_22789-130,153,0xffeeeeee);
  if(!hoverReason.isEmpty()){ctx.method_27535(field_22793,class_2561.method_43471("hint.hidenseek."+hoverReason),field_22789-130,175,0xffeeaaaa);hoverReason="";}
 }
 private String hoverReason="";
 public boolean method_25402(double x,double y,int button){
  if(tab==0&&x>=12&&x<12+mapSide()&&y>=68&&y<68+mapSide()&&(button==0||button==1)){
   var o=action("mark");o.addProperty("x",(x-12-panX)/scale()+number(view,"originX",0));o.addProperty("z",(y-68-panZ)/scale()+number(view,"originZ",0));o.addProperty("label",label.method_1882());o.addProperty("team",button==1);intent(o);return true;
  }return super.method_25402(x,tab!=0&&y>=64?y+scroll:y,button);
 }
 public boolean method_25403(double x,double y,int button,double dx,double dy){if(tab==0&&button==2){panX+=dx;panZ+=dy;return true;}return super.method_25403(x,y,button,dx,dy);}
 public boolean method_25401(double x,double y,double horizontal,double vertical){if(tab==0){zoom=class_3532.method_15350(zoom*Math.pow(1.2,vertical),.5,8);return true;}int content=tab==1?300+(view.has("history")?view.getAsJsonArray("history").size()*13:0):350;scroll=class_3532.method_15340(scroll-(int)(vertical*24),0,Math.max(0,content-field_22790+24));return true;}
}

