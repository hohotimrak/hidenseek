package dev.hidenseek.mixin;
import dev.hidenseek.StillHunt;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(class_1309.class)
public abstract class LivingMixin {
 @Inject(method="tickGliding",at=@At("HEAD"),cancellable=true)
 private void virtualEquipment(CallbackInfo ci){var e=(class_1309)(Object)this;var mod=StillHunt.INSTANCE;if(mod!=null&&!e.method_37908().field_9236&&mod.match.active()&&mod.match.effect(e.method_5667(),"flight"))ci.cancel();}
 @Inject(method="canGlide",at=@At("HEAD"),cancellable=true)
 private void pocketWings(CallbackInfoReturnable<Boolean> ci){var e=(class_1309)(Object)this;var mod=StillHunt.INSTANCE;if(mod!=null&&!e.method_37908().field_9236&&mod.match.active()&&mod.match.effect(e.method_5667(),"flight")&&!e.method_24828())ci.setReturnValue(true);}
 @Inject(method="jump",at=@At("HEAD"),cancellable=true)
 private void noJump(CallbackInfo ci){if(StillHunt.noJump((class_1309)(Object)this))ci.cancel();}
 @Inject(method="isPushable",at=@At("HEAD"),cancellable=true)
 private void noPush(CallbackInfoReturnable<Boolean> ci){var e=(class_1309)(Object)this;if(StillHunt.locked(e)||StillHunt.temporary(e))ci.setReturnValue(false);}
}
