package dev.hidenseek.mixin;
import dev.hidenseek.StillHunt;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(class_1297.class)
public abstract class EntityMixin {
 @Inject(method="move",at=@At("HEAD"),cancellable=true)
 private void stopMove(class_1313 type,class_243 movement,CallbackInfo ci){if(StillHunt.movementBlocked((class_1297)(Object)this))ci.cancel();}
 @Inject(method="setPosition(DDD)V",at=@At("HEAD"),cancellable=true)
 private void stopPosition(double x,double y,double z,CallbackInfo ci){if(StillHunt.locked((class_1297)(Object)this))ci.cancel();}
 @Inject(method="setVelocity(Lnet/minecraft/util/math/Vec3d;)V",at=@At("HEAD"),cancellable=true)
 private void stopVelocity(class_243 v,CallbackInfo ci){if(StillHunt.locked((class_1297)(Object)this))ci.cancel();}
 @Inject(method="isPushable",at=@At("HEAD"),cancellable=true)
 private void noPush(CallbackInfoReturnable<Boolean> ci){class_1297 e=(class_1297)(Object)this;if(StillHunt.locked(e)||StillHunt.temporary(e))ci.setReturnValue(false);}
 @Inject(method="canAvoidTraps",at=@At("HEAD"),cancellable=true)
 private void noTraps(CallbackInfoReturnable<Boolean> ci){if(StillHunt.temporary((class_1297)(Object)this))ci.setReturnValue(true);}
 @Inject(method="setSprinting",at=@At("HEAD"),cancellable=true)
 private void noSprint(boolean sprint,CallbackInfo ci){if(sprint&&StillHunt.noSprint((class_1297)(Object)this))ci.cancel();}
}
