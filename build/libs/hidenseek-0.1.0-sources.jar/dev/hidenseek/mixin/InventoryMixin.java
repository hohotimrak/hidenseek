package dev.hidenseek.mixin;
import dev.hidenseek.StillHunt;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1657.class)
public abstract class InventoryMixin {
 @Inject(method="dropInventory",at=@At("HEAD"),cancellable=true)
 private void keepRemainingKit(CallbackInfo ci){var mod=StillHunt.INSTANCE;if(mod!=null&&mod.match.active()&&mod.match.seeker(((class_1657)(Object)this).method_5667()))ci.cancel();}
}
