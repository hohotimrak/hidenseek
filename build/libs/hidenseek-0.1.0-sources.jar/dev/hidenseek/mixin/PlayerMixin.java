package dev.hidenseek.mixin;
import dev.hidenseek.StillHunt;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_5454;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_3222.class)
public abstract class PlayerMixin {
 @Inject(method="copyFrom",at=@At("TAIL"))
 private void preserveInventory(class_3222 old,boolean alive,CallbackInfo ci){var p=(class_3222)(Object)this;var mod=StillHunt.INSTANCE;if(mod!=null&&mod.match.active()&&mod.match.seeker(p.method_5667()))p.method_31548().method_7377(old.method_31548());}
 @Inject(method="teleportTo(Lnet/minecraft/world/TeleportTarget;)Lnet/minecraft/server/network/ServerPlayerEntity;",at=@At("HEAD"),cancellable=true)
 private void blockTeleport(class_5454 target,CallbackInfoReturnable<class_3222> ci){var p=(class_3222)(Object)this;var mod=StillHunt.INSTANCE;if(StillHunt.locked(p)||mod!=null&&!mod.restoring&&mod.match.active()&&mod.match.participants.containsKey(p.method_5667())&&!target.comp_2820().method_27983().method_29177().toString().equals(mod.match.dimension))ci.setReturnValue(null);}
 @Inject(method="startRiding",at=@At("HEAD"),cancellable=true)
 private void blockMount(class_1297 mount,boolean force,CallbackInfoReturnable<Boolean> ci){if(StillHunt.locked((class_1297)(Object)this))ci.setReturnValue(false);}
}
