package dev.hidenseek.mixin;
import dev.hidenseek.StillHunt;
import net.minecraft.class_2828;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_3244.class)
public abstract class NetworkMixin {
 @Shadow public class_3222 player;
 @Inject(method="onPlayerMove",at=@At(value="INVOKE",target="Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/server/world/ServerWorld;)V",shift=At.Shift.AFTER),cancellable=true)
 private void freeze(class_2828 packet,CallbackInfo ci){if(StillHunt.movementBlocked(player)){
  float yaw=packet.method_12271(player.method_36454()),pitch=packet.method_12270(player.method_36455());
  if(Float.isFinite(yaw)&&Float.isFinite(pitch)){player.method_36456(yaw);player.method_36457(Math.clamp(pitch,-90,90));}ci.cancel();
 }}
}
