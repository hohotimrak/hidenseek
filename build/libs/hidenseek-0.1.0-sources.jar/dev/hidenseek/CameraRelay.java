package dev.hidenseek;

import net.minecraft.class_1923;
import net.minecraft.class_2672;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3222;
import net.minecraft.class_4282;
import net.minecraft.network.packet.s2c.play.*;
import java.util.*;

/** Bounded snapshot streaming of already-loaded chunks; never moves the player's entity. */
public final class CameraRelay {
 private class_1923 center;
 private final ArrayDeque<class_1923> pending=new ArrayDeque<>();
 private boolean remote;
 public void tick(class_3222 viewer,class_3222 target){
  boolean nextRemote=target!=null;if(target==null)target=viewer;
  class_1923 next=target.method_31476();
  if(!next.equals(center)||remote!=nextRemote){
   center=next;remote=nextRemote;pending.clear();
   viewer.field_13987.method_14364(new class_4282(next.field_9181,next.field_9180));
   int radius=remote?3:Math.min(10,viewer.method_5682().method_3760().method_14568());
   // Near chunks first, then expanding square rings.
   for(int r=0;r<=radius;r++)for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(Math.max(Math.abs(x),Math.abs(z))==r)pending.add(new class_1923(next.field_9181+x,next.field_9180+z));
  }
  for(int i=0;i<2&&!pending.isEmpty();i++){
   class_1923 p=pending.remove();var chunk=target.method_51469().method_14178().method_12121(p.field_9181,p.field_9180,class_2806.field_12803,false);
   if(chunk instanceof class_2818 full)viewer.field_13987.method_14364(new class_2672(full,target.method_51469().method_22336(),null,null));
  }
 }
}
