package dev.hidenseek;

import com.google.gson.*;
import dev.hidenseek.core.*;
import dev.hidenseek.core.Geometry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.event.player.*;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1428;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5218;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.nio.file.*;
import java.util.*;
import org.slf4j.*;
import static net.minecraft.class_2170.*;

public class StillHunt implements ModInitializer {
 public static final Logger LOG=LoggerFactory.getLogger("StillHunt");
 public static StillHunt INSTANCE;
 public Match match=new Match();public Rules rules=new Rules();
 public MinecraftServer server;private Path savePath;
 private final Map<UUID,Long> lastIntent=new HashMap<>();
 private final Map<UUID,Long> temporary=new HashMap<>();
 private final Map<UUID,UUID> cameras=new HashMap<>();
 private final Map<UUID,CameraRelay> relays=new HashMap<>();
 private long ticks;
 private final TerrainMap terrain=new TerrainMap();
 private final Map<String,ImageTransfer> images=new HashMap<>();
 private final Map<UUID,Map<String,Object>> quotes=new HashMap<>();
 public boolean restoring;
 public static boolean locked(class_1297 e){return INSTANCE!=null&&e instanceof class_3222 p&&INSTANCE.match.active()&&INSTANCE.match.hider(p.method_5667())&&INSTANCE.match.hide!=null&&!INSTANCE.restoring;}
 public static boolean movementBlocked(class_1297 e){return locked(e)||INSTANCE!=null&&e instanceof class_3222&&INSTANCE.match.phase==Match.Phase.PAUSED&&INSTANCE.match.participants.containsKey(e.method_5667());}
 public static boolean noJump(class_1297 e){return locked(e)||INSTANCE!=null&&INSTANCE.match.active()&&INSTANCE.match.effect(e.method_5667(),"boots");}
 public static boolean noSprint(class_1297 e){return locked(e)||INSTANCE!=null&&INSTANCE.match.active()&&INSTANCE.match.effect(e.method_5667(),"rhythm");}
 public static boolean temporary(class_1297 e){return e.method_5752().contains("stillhunt.temporary");}
 public void onInitialize(){
  INSTANCE=this;
  PayloadTypeRegistry.playC2S().register(Wire.Intent.ID,Wire.Intent.CODEC);PayloadTypeRegistry.playS2C().register(Wire.View.ID,Wire.View.CODEC);
  PayloadTypeRegistry.playS2C().register(Wire.Tiles.ID,Wire.Tiles.CODEC);
  PayloadTypeRegistry.playC2S().register(Wire.ImagePart.ID,Wire.ImagePart.CODEC);PayloadTypeRegistry.playS2C().register(Wire.ImagePart.ID,Wire.ImagePart.CODEC);
  ServerPlayNetworking.registerGlobalReceiver(Wire.ImagePart.ID,(payload,ctx)->ctx.server().execute(()->receiveImage(ctx.player(),payload)));
  ServerPlayNetworking.registerGlobalReceiver(Wire.Intent.ID,(payload,ctx)->ctx.server().execute(()->handle(ctx.player(),payload.json())));
  ServerLifecycleEvents.SERVER_STARTED.register(s->{server=s;savePath=s.method_27050(class_5218.field_24188).resolve("stillhunt/match.json");try{
   Path config=FabricLoader.getInstance().getConfigDir().resolve("stillhunt.json");rules=Storage.read(config,Rules.class,new Rules());rules.validate();Storage.write(config,rules);
   Path contentPath=FabricLoader.getInstance().getConfigDir().resolve("stillhunt-content.json");rules.content=Storage.read(contentPath,ContentCatalog.class,ContentCatalog.defaults());rules.content.validate(ContentRegistry.cardHandlers(),ContentRegistry.taskObjectives());Storage.write(contentPath,rules.content);
   for(String hint:rules.tiers.keySet())if(!HintRegistry.has(hint))throw new IllegalArgumentException("Unregistered hint handler: "+hint);
   match=Storage.read(savePath,Match.class,new Match());if(match.active()){if(match.rulesSnapshot!=null)rules=match.rulesSnapshot;if(match.contentSnapshot!=null)rules.content=match.contentSnapshot;match.pause();}for(String id:new ArrayList<>(match.pending.keySet()))match.completeImage(id,false,rules);
   // Only entities carrying our namespaced tag are stale temporary entities.
   for(class_3218 w:s.method_3738())for(class_1297 e:w.method_27909())if(temporary(e))e.method_31472();
   if(Boolean.getBoolean("stillhunt.smoke")){RuntimeChecks.run(this);s.method_3747(false);}
  }catch(Exception e){throw new IllegalStateException("Still Hunt save/config failed; refusing silent reset",e);}});
  ServerLifecycleEvents.SERVER_STOPPING.register(s->save());
  ServerTickEvents.END_SERVER_TICK.register(this::tick);
  ServerPlayConnectionEvents.JOIN.register((h,sender,s)->{if(match.participants.containsKey(h.field_14140.method_5667()))restorePlayer(h.field_14140);send(h.field_14140);});
  AttackEntityCallback.EVENT.register((player,world,hand,target,hit)->{
   if(world.field_9236)return class_1269.field_5811;
   if(match.active()&&match.hider(player.method_5667())||match.phase==Match.Phase.PAUSED&&match.participants.containsKey(player.method_5667()))return class_1269.field_5814;
   if(target instanceof class_3222 h&&match.hider(h.method_5667())&&match.active()){
    if(match.phase==Match.Phase.SEEKING&&match.seeker(player.method_5667())&&player.method_5805()&&!player.method_7325()&&player.method_5858(h)<=9&&player.method_6057(h))finish("seekers");
    return class_1269.field_5814;
   }return class_1269.field_5811;
  });
  AttackBlockCallback.EVENT.register((p,w,h,pos,d)->match.active()&&match.hider(p.method_5667())?class_1269.field_5814:class_1269.field_5811);
  UseBlockCallback.EVENT.register((p,w,h,hit)->match.active()&&match.hider(p.method_5667())?class_1269.field_5814:class_1269.field_5811);
  UseItemCallback.EVENT.register((p,w,h)->match.active()&&match.hider(p.method_5667())?class_1269.field_5814:class_1269.field_5811);
  UseEntityCallback.EVENT.register((p,w,h,e,hit)->match.active()&&match.hider(p.method_5667())?class_1269.field_5814:class_1269.field_5811);
  PlayerBlockBreakEvents.BEFORE.register((w,p,pos,state,be)->!(match.active()&&match.hider(p.method_5667())));
  PlayerBlockBreakEvents.AFTER.register((w,p,pos,state,be)->{if(match.phase==Match.Phase.SEEKING&&match.seeker(p.method_5667()))ContentRegistry.taskEvent(this,p.method_5667(),"break_block",class_7923.field_41175.method_10221(state.method_26204()).toString());});
  ServerLivingEntityEvents.ALLOW_DAMAGE.register((e,source,amount)->{
   if(movementBlocked(e))return false;
   var p=match.participants.get(e.method_5667());if(match.active()&&p!=null&&p.protectedUntil>match.tick)return false;
   if(match.active()&&p!=null&&source.method_48789(net.minecraft.class_8103.field_42250)&&(p.fallGuard||match.effect(e.method_5667(),"landing"))){p.fallGuard=false;return false;}
   return !temporary(e);
  });
  ServerLivingEntityEvents.AFTER_DEATH.register((e,source)->{
   if(e instanceof class_3222 p&&match.phase==Match.Phase.SEEKING&&match.seeker(p.method_5667())){
    match.death(p.method_5667(),p.method_5667()+":"+match.tick,rules);save();
   }
  });
  ServerPlayerEvents.AFTER_RESPAWN.register((old,p,alive)->{if(match.active()&&match.seeker(p.method_5667())){var data=match.participants.get(p.method_5667());data.protectedUntil=Math.max(data.respawnAt+100,match.tick+100);teleport(p,match.waiting);}});
  CommandRegistrationCallback.EVENT.register((dispatcher,access,environment)->dispatcher.register(method_9247("hunt")
   .then(method_9247("start").requires(s->s.method_9259(2)).then(method_9244("hider",class_2186.method_9305()).then(method_9244("seeker1",class_2186.method_9305()).then(method_9244("seeker2",class_2186.method_9305()).executes(ctx->{start(class_2186.method_9315(ctx,"hider"),class_2186.method_9315(ctx,"seeker1"),class_2186.method_9315(ctx,"seeker2"));return 1;})))))
   .then(method_9247("stop").requires(s->s.method_9259(2)).executes(ctx->{finish("admin");return 1;}))
   .then(method_9247("pause").requires(s->s.method_9259(2)).executes(ctx->{match.pause();save();return 1;}))
   .then(method_9247("resume").requires(s->s.method_9259(2)).executes(ctx->{if(present())match.resume();save();return 1;}))
   .then(method_9247("cancel_effects").requires(s->s.method_9259(2)).then(method_9244("player",class_2186.method_9305()).executes(ctx->{var p=match.participants.get(class_2186.method_9315(ctx,"player").method_5667());if(p!=null){p.effects.clear();p.slots.clear();ContentRegistry.clearTask(p);}return 1;})))
   .then(method_9247("action").then(method_9244("json",StringArgumentType.greedyString()).executes(ctx->{handle(ctx.getSource().method_9207(),StringArgumentType.getString(ctx,"json"));return 1;})))
   .executes(ctx->{send(ctx.getSource().method_9207());ctx.getSource().method_9226(()->class_2561.method_43471("hunt.help"),false);return 1;})));
 }
 private void start(class_3222 h,class_3222 a,class_3222 b){
  if(match.active()){message(h,"active");return;}
  if(h==a||h==b||a==b||h.method_51469()!=a.method_51469()||a.method_51469()!=b.method_51469()){message(h,"roles");return;}
  for(var p:List.of(h,a,b))if(!ServerPlayNetworking.canSend(p,Wire.View.ID)||p.method_7325()||p.method_68878()){message(h,"clients");return;}
  match=new Match();int size=rules.arenaSize;
  match.start(h.method_5667(),List.of(a.method_5667(),b.method_5667()),point(a),Math.floorDiv(h.method_31477(),16)*16-size/2,Math.floorDiv(h.method_31479(),16)*16-size/2,h.method_51469().method_27983().method_29177().toString(),rules);
  for(var p:List.of(h,a,b)){p.method_7353(class_2561.method_43471("hunt.notice"),false);send(p);}save();
 }
 private boolean present(){return server.method_3760().method_14602(match.hider)!=null&&match.seekers.stream().anyMatch(u->server.method_3760().method_14602(u)!=null);}
 private void tick(MinecraftServer s){
  ticks++;for(var e:relays.entrySet()){var viewer=s.method_3760().method_14602(e.getKey());if(viewer!=null)e.getValue().tick(viewer,cameras.containsKey(e.getKey())?s.method_3760().method_14602(cameras.get(e.getKey())):null);}
  if(!match.active()){if(ticks%20==0)broadcast();return;}
  if(!present()&&match.phase!=Match.Phase.PAUSED)match.pause();
  if(match.phase==Match.Phase.PAUSED&&!present()){
   if(++match.absenceTicks>=rules.disconnectSeconds*20L)finish(s.method_3760().method_14602(match.hider)==null?"seekers":"hider");
  }
  match.advance(rules);
  images.keySet().removeIf(id->!match.pending.containsKey(id));
  var arena=server.method_3847(class_5321.method_29179(class_7924.field_41223,class_2960.method_60654(match.dimension)));
  if(arena!=null){var tiles=terrain.sample(arena,match,rules);if(!tiles.isEmpty()){var packet=new Wire.Tiles(Storage.JSON.toJson(Map.of("match",match.id,"tiles",tiles)));for(UUID u:match.participants.keySet()){var q=server.method_3760().method_14602(u);if(q!=null&&ServerPlayNetworking.canSend(q,Wire.Tiles.ID))ServerPlayNetworking.send(q,packet);}}}
  if(match.phase==Match.Phase.FINISHED){cleanup();save();}
  if(match.phase==Match.Phase.HIDING&&match.phaseTicks>=rules.hidingSeconds*20L){
   var h=s.method_3760().method_14602(match.hider);String reason=validHide(h);
   if(reason==null){for(UUID u:match.participants.keySet()){var data=match.participants.get(u);if(data.kit.isEmpty())data.kit=data.kits.getFirst();var q=s.method_3760().method_14602(u);if(q!=null)giveKit(q,data);}h.method_5848();h.method_18799(class_243.field_1353);match.lock(point(h));save();broadcast();}
   else if(ticks%100==0)message(h,reason);
  }
  for(UUID u:match.participants.keySet()){
   var p=s.method_3760().method_14602(u);if(p==null)continue;
   var data=match.participants.get(u);
   if(match.seeker(u)){
    if(!p.method_5805()&&data.respawnAt>0&&data.respawnAt<=match.tick&&match.phase==Match.Phase.SEEKING){server.method_3760().method_14556(p,false,class_1297.class_5529.field_26998);data.respawnAt=0;continue;}
    if(match.effect(u,"flight")){if(!p.method_24828())p.method_23669();}
    else if(data.effects.containsKey("flight")){data.effects.remove("flight");p.method_66281();data.effects.put("landing",match.tick+600);}
    if(match.effect(u,"landing")){if(p.method_24828())data.effects.remove("landing");else if(p.method_18798().field_1351<-.25){p.method_18799(p.method_18798().method_18805(1,0,1).method_1031(0,-.25,0));p.field_6037=true;}}
    if(match.phase==Match.Phase.HIDING||data.respawnAt>match.tick){if(p.method_5707(vec(match.waiting))>0.25)teleport(p,match.waiting);}
    if(match.phase==Match.Phase.SEEKING&&!inside(point(p)))teleport(p,match.waiting);
    if(match.effect(u,"rhythm"))p.method_5728(false);
    if(match.effect(u,"noise")&&ticks%20==0){p.method_51469().method_60511(null,p.method_23317(),p.method_23318(),p.method_23321(),class_3417.field_14793,class_3419.field_15248,1,1);p.method_51469().method_65096(class_2398.field_11224,p.method_23317(),p.method_23318()+2,p.method_23321(),2,0.1,0.1,0.1,0);}
    if(match.phase==Match.Phase.SEEKING)ContentRegistry.taskEvent(this,u,"tick","");
    if(data.challengeAccepted&&match.tick>=data.challengeEnd){data.challengeAccepted=false;data.challengeComplete=true;data.challengesCompleted++;data.wings++;message(p,"challenge_won");}
   }
  }
  temporary.entrySet().removeIf(e->{if(match.tick<e.getValue()&&match.active())return false;for(var w:s.method_3738()){var entity=w.method_66347(e.getKey());if(entity!=null)entity.method_31472();}return true;});
  if(ticks%20==0)broadcast();if(ticks%100==0)save();
 }
 private String validHide(class_3222 p){
  if(p==null)return "missing";
  if(!inside(point(p))||!p.method_51469().method_27983().method_29177().toString().equals(match.dimension))return "outside";
  if(!p.method_24828()||p.method_5765()||p.method_5799()||p.method_5771()||!p.method_51469().method_17892(p))return "unsafe_hide";
  return null;
 }
 private boolean inside(Point p){return p.x()>=match.originX&&p.x()<match.originX+rules.arenaSize&&p.z()>=match.originZ&&p.z()<match.originZ+rules.arenaSize&&p.y()>=rules.minY&&p.y()<rules.maxY;}
 private void restorePlayer(class_3222 p){if(match.hider(p.method_5667())&&match.hide!=null)teleport(p,match.hide);}
 private void teleport(class_3222 p,Point at){if(at==null)return;var w=server.method_3847(class_5321.method_29179(class_7924.field_41223,class_2960.method_60654(match.dimension)));if(w==null)return;restoring=true;try{p.method_48105(w,at.x(),at.y(),at.z(),Set.of(),p.method_36454(),p.method_36455(),true);}finally{restoring=false;}}
 public void finish(String who){match.finish(who);cleanup();save();broadcast();}
 private void cleanup(){cameras.clear();images.clear();for(String id:new ArrayList<>(match.pending.keySet()))match.completeImage(id,false,rules);for(var world:server.method_3738())for(class_1297 e:world.method_27909())if(temporary(e))e.method_31472();temporary.clear();for(var p:match.participants.values())p.effects.clear();}
 private void save(){if(savePath!=null)try{Storage.write(savePath,match);}catch(Exception e){LOG.error("Cannot save match",e);match.pause();}}
 private void broadcast(){for(var p:server.method_3760().method_14571())if(ServerPlayNetworking.canSend(p,Wire.View.ID))send(p);}
 private void send(class_3222 p){
  if(!ServerPlayNetworking.canSend(p,Wire.View.ID))return;
  var view=match.view(p.method_5667(),rules);
  if(match.active()&&match.participants.containsKey(p.method_5667())){
   List<Map<String,Object>> positions=new ArrayList<>();for(UUID u:match.seekers){var q=server.method_3760().method_14602(u);if(q!=null)positions.add(Map.of("id",u.toString(),"name",q.method_5477().getString(),"x",q.method_23317(),"y",q.method_23318(),"z",q.method_23321(),"yaw",q.method_36454(),"pitch",q.method_36455()));}view.put("positions",positions);
   if(match.hider(p.method_5667())&&cameras.containsKey(p.method_5667())){UUID target=cameras.get(p.method_5667());if(server.method_3760().method_14602(target)!=null)view.put("camera",target.toString());else cameras.remove(p.method_5667());}
   if(match.hider(p.method_5667())&&!match.pending.isEmpty())view.put("imageRequest",match.pending.keySet().iterator().next());
   if(match.hider(p.method_5667())){Map<String,Object> targets=new LinkedHashMap<>();for(UUID u:match.seekers){var data=match.participants.get(u);targets.put(u.toString(),Map.of("effects",data.effects,"task",data.taskId,"progress",data.taskProgress));}view.put("targets",targets);}
   if(match.seeker(p.method_5667())&&quotes.containsKey(p.method_5667()))view.put("quote",quotes.get(p.method_5667()));
  }
  ServerPlayNetworking.send(p,new Wire.View(Storage.JSON.toJson(view)));
 }
 private void message(class_3222 p,String key){if(p!=null)p.method_7353(class_2561.method_43471("hunt."+key),false);}
 private static Point point(class_1297 e){return new Point(e.method_23317(),e.method_23318(),e.method_23321());}
 private static class_243 vec(Point p){return new class_243(p.x(),p.y(),p.z());}
 private static String str(JsonObject o,String key,String fallback){return o.has(key)?o.get(key).getAsString():fallback;}
 private static double num(JsonObject o,String key,double fallback){double n=o.has(key)?o.get(key).getAsDouble():fallback;if(!Double.isFinite(n)||Math.abs(n)>30000000)throw new IllegalArgumentException("number");return n;}
 private void handle(class_3222 p,String json){
  if(ticks-lastIntent.getOrDefault(p.method_5667(),-100L)<3)return;lastIntent.put(p.method_5667(),ticks);
  try{
   JsonObject o=JsonParser.parseString(json).getAsJsonObject();if(!str(o,"match","").equals(match.id)||!match.participants.containsKey(p.method_5667())||!p.method_5805()||p.method_7325()||match.participants.get(p.method_5667()).respawnAt>match.tick)return;
   String action=str(o,"action","");
   switch(action){
    case "quote" -> {if(match.seeker(p.method_5667())){String kind=str(o,"kind","");int tier=quoteTier(kind,o);if(tier>0)quotes.put(p.method_5667(),Map.of("kind",kind,"tier",tier,"cost",rules.costs[tier-1],"history",match.history.size()));}}
    case "hint" -> hint(p,o);
    case "kit" -> {var data=match.participants.get(p.method_5667());String kit=str(o,"kit","");if(match.phase==Match.Phase.HIDING&&data.kit.isEmpty()&&data.kits.contains(kit)){data.kit=kit;giveKit(p,data);}}
    case "choose" -> {if(match.hider(p.method_5667())&&match.phase==Match.Phase.SEEKING&&str(o,"offer","").equals(match.offerId))match.choose((int)num(o,"index",-1),(int)num(o,"replace",-1),rules);}
    case "card" -> playCard(p,o);
    case "camera" -> {if(match.hider(p.method_5667())&&match.phase==Match.Phase.SEEKING){String target=str(o,"target","");relays.computeIfAbsent(p.method_5667(),u->new CameraRelay());if(target.isEmpty())cameras.remove(p.method_5667());else{UUID u=UUID.fromString(target);if(match.seeker(u))cameras.put(p.method_5667(),u);}}}
    case "mark" -> mark(p,o);
    case "challenge" -> {var data=match.participants.get(p.method_5667());if(match.seeker(p.method_5667())&&match.phase==Match.Phase.SEEKING&&data.challengesCompleted<rules.challengeAtSeconds.size()&&match.phaseTicks>=rules.challengeAtSeconds.get(data.challengesCompleted)*20L&&!data.challengeAccepted&&!match.effect(p.method_5667(),"scavenge")&&!match.effect(p.method_5667(),"silence")&&match.phaseTicks+rules.challengeDurationSeconds*20L<rules.seekingSeconds*20L){data.challengeAccepted=true;data.challengeEnd=match.tick+rules.challengeDurationSeconds*20L;}}
    case "antidote" -> {var data=match.participants.get(p.method_5667());if(data.antidotes>0&&match.phase==Match.Phase.SEEKING){for(String key:List.of("boots","rhythm","noise"))if(match.effect(p.method_5667(),key)){data.effects.remove(key);data.antidotes--;break;}}}
    case "wings" -> {var data=match.participants.get(p.method_5667());if(match.seeker(p.method_5667())&&match.phase==Match.Phase.SEEKING&&data.wings>0&&!match.effect(p.method_5667(),"flight")&&!match.effect(p.method_5667(),"quarantine")&&!match.effect(p.method_5667(),"pilgrimage")){data.wings--;data.effects.put("flight",match.tick+20L*rules.flightSeconds);p.method_18799(p.method_5828(1).method_1021(1.3).method_1031(0,.8,0));p.field_6037=true;}}
    case "kit_power" -> {var data=match.participants.get(p.method_5667());if(match.phase==Match.Phase.SEEKING){switch(data.kit){
     case "engineer" -> {if(!data.engineerUsed&&data.antidotes==0){data.antidotes++;data.engineerUsed=true;}}
     case "naturalist" -> {if(!data.naturalistUsed&&!data.taskId.isEmpty()){ContentRegistry.clearTask(data);data.naturalistUsed=true;}}
     case "tactician" -> {if(!match.offer.isEmpty()&&data.refreshedAct<match.act(rules)){int rarity=match.offer.getFirst().rarity();match.offer.clear();match.reward(rarity,rules);data.refreshedAct=match.act(rules);}}
     case "archivist" -> {if(!data.engineerUsed&&match.hand.size()>=2&&match.hand.get(0).rarity()==1&&match.hand.get(1).rarity()==1){match.hand.removeFirst();match.hand.removeFirst();match.reward(1,rules);data.engineerUsed=true;}}
    }}}
   }
   save();send(p);
  }catch(RuntimeException e){message(p,"invalid");LOG.debug("Rejected invalid intent",e);}
 }
 private void giveKit(class_3222 p,Match.Participant data){
  if(data.kitGiven)return;data.kitGiven=true;
  if(match.seeker(p.method_5667())){p.method_7270(new class_1799(class_1802.field_8387));p.method_7270(new class_1799(class_1802.field_8229,16));if(data.kit.equals("climber")){p.method_7270(new class_1799(class_1802.field_8121,24));data.fallGuard=true;}if(data.kit.equals("naturalist")||data.kit.equals("engineer"))data.antidotes++;}
 }
 private void mark(class_3222 p,JsonObject o){
  if(!match.seeker(p.method_5667())||!match.active())return;String delete=str(o,"delete","");
  if(!delete.isEmpty()){match.marks.removeIf(m->m.id().equals(delete)&&m.author().equals(p.method_5667()));return;}
  if(match.marks.stream().filter(m->m.author().equals(p.method_5667())).count()>=32)return;
  double x=num(o,"x",0),z=num(o,"z",0);if(!inside(new Point(x,rules.minY,z)))return;String label=str(o,"label","?");if(label.length()>32)return;
  match.marks.add(new Match.Mark(UUID.randomUUID().toString(),p.method_5667(),o.has("team")&&o.get("team").getAsBoolean(),x,z,label,0xffffcc55,str(o,"icon","suspect"),str(o,"icon","").equals("ping")?match.tick+200:0));
 }
 private void playCard(class_3222 p,JsonObject o){
  if(!match.hider(p.method_5667())||match.phase!=Match.Phase.SEEKING)return;
  String id=str(o,"card","");var card=match.hand.stream().filter(c->c.id().equals(id)).findFirst().orElse(null);if(card==null)return;
  UUID target=UUID.fromString(str(o,"target",""));if(!match.seeker(target))return;
  var data=match.participants.get(target);var definition=rules.content.cards.get(card.kind());if(definition==null||!rules.content.profile.containsAll(definition.requires()))return;
  int duration=definition.durationSeconds();String category=definition.category();
  if(data.slots.getOrDefault(category,0L)>match.tick||category.equals("heavy")&&data.immunityUntil>match.tick||match.phaseTicks+duration*20L>=rules.seekingSeconds*20L){message(p,"restricted");return;}
  if(!ContentRegistry.apply(new ContentRegistry.CardContext(this,p,target,definition))){message(p,"invalid");return;}
  data.slots.put(category,match.tick+duration*20L);
  if(category.equals("heavy"))data.immunityUntil=match.tick+20L*(duration+rules.heavyImmunitySeconds);
  match.hand.remove(card);var q=server.method_3760().method_14602(target);if(q!=null)q.method_7353(class_2561.method_43469("hunt.card_applied",class_2561.method_43470(definition.names().getOrDefault(q.method_53823().comp_1951(),definition.names().get("en_us"))),duration),false);
 }
 public boolean spawnDecoys(int count,int duration){
  var w=server.method_3847(class_5321.method_29179(class_7924.field_41223,class_2960.method_60654(match.dimension)));if(w==null)return false;
  for(int i=0;i<count;i++){var at=class_2338.method_49637(match.waiting.x()+i*4,match.waiting.y(),match.waiting.z()+4);var e=class_1299.field_6131.method_5883(w,class_3730.field_16462);if(e!=null){e.method_5725(at,0,0);e.method_5780("stillhunt.temporary");e.method_5665(class_2561.method_43471("hunt.decoy"));e.method_5880(false);w.method_8649(e);temporary.put(e.method_5667(),match.tick+duration*20L);}}return true;
 }
 private void hint(class_3222 p,JsonObject o){
  String kind=str(o,"kind",""),request=str(o,"request","");if(request.isEmpty())return;
  int tier=quoteTier(kind,o);if(o.has("quotedTier")&&o.get("quotedTier").getAsInt()!=tier){message(p,"quote_changed");return;}
  var result=match.purchase(request,p.method_5667(),kind,o.toString(),point(p),rules,tier,()->HintRegistry.evaluate(new HintRegistry.Context(this,p,request,kind,o)));
  if(result.ok())p.method_7353(class_2561.method_43470("☠".repeat(result.tier())+" ").method_10852(class_2561.method_43471("hint.hidenseek."+kind)).method_27693(": "+result.message()),false);else message(p,result.message());
 }
 private int quoteTier(String kind,JsonObject o){
  Constraint shape=null;
  if(kind.equals("circle"))shape=new Constraint("preview",kind,num(o,"x",0),num(o,"z",0),num(o,"radius",128),0,false,match.tick);
  else if(kind.equals("rectangle")||kind.equals("sector")){double x=num(o,"x",0),z=num(o,"z",0);shape=new Constraint("preview",kind,x,z,num(o,"x2",x+128),num(o,"z2",z+128),false,match.tick);}
  return Pricing.tier(match,rules,kind,shape);
 }
 public Match.Evaluation evaluateBuiltIn(class_3222 p,String kind,String request,JsonObject o){
  if(match.hide==null||!p.method_51469().method_27983().method_29177().toString().equals(match.dimension))return null;
  class_3218 w=p.method_51469();Point h=match.hide;double a=0,b=0,c=0,d=0;
  switch(kind){
   case "east" -> a=p.method_23317();case "south" -> a=p.method_23321();case "above" -> {a=num(o,"y",64);if(a%16!=0||a<rules.minY||a>rules.maxY)return null;}
   case "distance" -> {a=p.method_23317();b=p.method_23321();c=num(o,"radius",128);if(!rules.radii.contains((int)c)||c!=(int)c)return null;}
   case "circle" -> {a=num(o,"x",0);b=num(o,"z",0);c=num(o,"radius",128);if(!rules.radii.contains((int)c)||c!=(int)c||!inside(new Point(a,rules.minY,b)))return null;}
   case "sector","rectangle" -> {a=num(o,"x",0);b=num(o,"z",0);c=num(o,"x2",a+128);d=num(o,"z2",b+128);if(c-a<64||d-b<64||c-a>rules.arenaSize||d-b>rules.arenaSize||a%16!=0||b%16!=0||c%16!=0||d%16!=0)return null;if(kind.equals("sector")&&(c-a!=128||d-b!=128||Math.floorMod((int)a-match.originX,128)!=0||Math.floorMod((int)b-match.originZ,128)!=0))return null;}
   case "block" -> {
    String block=str(o,"block","");if(!rules.blocks.contains(block))return null;int radius=rules.blockRadius;boolean found=false;class_2338 center=class_2338.method_49637(h.x(),h.y(),h.z());
    for(class_2338 q:class_2338.method_10097(center.method_10069(-radius,-radius,-radius),center.method_10069(radius,radius,radius)))if(q.method_46558().method_1025(vec(h))<=radius*radius){if(!w.method_22340(q))return null;if(class_7923.field_41175.method_10221(w.method_8320(q).method_26204()).toString().equals(block))found=true;}
    return new Match.Evaluation(Boolean.toString(found),null);
   }
   case "biome" -> {return new Match.Evaluation(w.method_23753(class_2338.method_49637(h.x(),h.y(),h.z())).method_40230().map(k->k.method_29177().toString()).orElse("unknown"),null);}
   case "biome_is" -> {String selected=str(o,"biome","");var id=class_2960.method_12829(selected);if(id==null||!w.method_30349().method_30530(class_7924.field_41236).method_10250(id))return null;return new Match.Evaluation(Boolean.toString(w.method_23753(class_2338.method_49637(h.x(),h.y(),h.z())).method_40230().map(k->k.method_29177().equals(id)).orElse(false)),null);}
   case "structure" -> {var pos=class_2338.method_49637(h.x(),h.y(),h.z());var registry=w.method_30349().method_30530(class_7924.field_41246);List<String> found=new ArrayList<>();for(var structure:registry)if(w.method_27056().method_38854(pos,structure).method_16657())found.add(registry.method_10221(structure).toString());Collections.sort(found);return new Match.Evaluation(found.isEmpty()?"outside":String.join(", ",found),null);}
   case "bearing" -> {int sector=Math.floorMod((int)Math.floor((Math.atan2(h.z()-p.method_23321(),h.x()-p.method_23317())+Math.PI/8)/(Math.PI/4)),8);return new Match.Evaluation(List.of("E","SE","S","SW","W","NW","N","NE").get(sector),new Constraint(request,"bearing",p.method_23317(),p.method_23321(),sector,0,true,match.tick));}
   case "screenshot" -> {if(!match.pending.isEmpty())return null;cameras.remove(match.hider);relays.computeIfAbsent(match.hider,u->new CameraRelay());return new Match.Evaluation("pending_image",null);}
   case "animal" -> {return spawnAnimal(w,h)?new Match.Evaluation("local_sound",null):null;}
   case "firework" -> {for(int y=0;y<20;y++){double height=h.y()+y;w.method_65096(class_2398.field_11248,h.x(),height,h.z(),10,.15,.15,.15,.03);if(!w.method_8320(class_2338.method_49637(h.x(),height+1,h.z())).method_26215())break;}w.method_43128(null,h.x(),h.y(),h.z(),class_3417.field_14702,class_3419.field_15256,2,1);return new Match.Evaluation("local_visual",null);}
   default -> {return null;}
  }
  Constraint probe=new Constraint(request,kind,a,b,c,d,false,match.tick);boolean answer=probe.test(h);
  return new Match.Evaluation(Boolean.toString(answer),new Constraint(request,kind,a,b,c,d,answer,match.tick));
 }
 private boolean spawnAnimal(class_3218 w,Point h){
  for(int dx:new int[]{2,-2,3,-3})for(int dz:new int[]{2,-2}){
   double x=h.x()+dx,z=h.z()+dz;class_2338 pos=class_2338.method_49637(x,h.y(),z);
   if(!w.method_22340(pos)||!w.method_8320(pos.method_10074()).method_26212(w,pos.method_10074())||!w.method_8320(pos).method_26215())continue;
   class_1428 e=class_1299.field_6132.method_5883(w,class_3730.field_16462);if(e==null)return false;e.method_5808(x,h.y(),z,0,0);
   if(!w.method_17892(e)){e.method_31472();continue;}e.method_5977(true);e.method_5684(true);e.method_5875(true);e.method_5780("stillhunt.temporary");w.method_8649(e);temporary.put(e.method_5667(),match.tick+600);return true;
  }return false;
 }
 private void receiveImage(class_3222 p,Wire.ImagePart part){
  if(!match.hider(p.method_5667())||match.phase!=Match.Phase.SEEKING||!part.match().equals(match.id)||!match.pending.containsKey(part.request()))return;
  try{
   ImageTransfer transfer=images.computeIfAbsent(part.request(),id->new ImageTransfer());
   if(transfer.accept(part.index(),part.total(),part.data())){
    byte[] bytes=transfer.bytes();if(!match.completeImage(part.request(),true,rules))return;images.remove(part.request());
    for(UUID u:match.seekers){var seeker=server.method_3760().method_14602(u);if(seeker==null)continue;for(int i=0;i<ImageTransfer.COUNT;i++)ServerPlayNetworking.send(seeker,new Wire.ImagePart(match.id,part.request(),i,ImageTransfer.COUNT,Arrays.copyOfRange(bytes,i*ImageTransfer.CHUNK,Math.min(bytes.length,(i+1)*ImageTransfer.CHUNK))));}
    save();broadcast();
   }
  }catch(RuntimeException e){images.remove(part.request());match.completeImage(part.request(),false,rules);save();}
 }
}
