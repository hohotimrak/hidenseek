package net.minecraft.client.realms;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import com.mojang.util.UndashedUuid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.realms.dto.BackupList;
import net.minecraft.client.realms.dto.Ops;
import net.minecraft.client.realms.dto.PendingInvite;
import net.minecraft.client.realms.dto.PendingInvitesList;
import net.minecraft.client.realms.dto.PingResult;
import net.minecraft.client.realms.dto.PlayerActivities;
import net.minecraft.client.realms.dto.PlayerInfo;
import net.minecraft.client.realms.dto.RealmsConfigurationDto;
import net.minecraft.client.realms.dto.RealmsDescriptionDto;
import net.minecraft.client.realms.dto.RealmsNews;
import net.minecraft.client.realms.dto.RealmsNotification;
import net.minecraft.client.realms.dto.RealmsOptionsDto;
import net.minecraft.client.realms.dto.RealmsRegion;
import net.minecraft.client.realms.dto.RealmsRegionDataList;
import net.minecraft.client.realms.dto.RealmsRegionSelectionPreference;
import net.minecraft.client.realms.dto.RealmsServer;
import net.minecraft.client.realms.dto.RealmsServerAddress;
import net.minecraft.client.realms.dto.RealmsServerList;
import net.minecraft.client.realms.dto.RealmsServerPlayerList;
import net.minecraft.client.realms.dto.RealmsSettingDto;
import net.minecraft.client.realms.dto.RealmsWorldOptions;
import net.minecraft.client.realms.dto.RealmsWorldResetDto;
import net.minecraft.client.realms.dto.RegionData;
import net.minecraft.client.realms.dto.RegionSelectionMethod;
import net.minecraft.client.realms.dto.Subscription;
import net.minecraft.client.realms.dto.UploadInfo;
import net.minecraft.client.realms.dto.WorldDownload;
import net.minecraft.client.realms.dto.WorldTemplatePaginatedList;
import net.minecraft.client.realms.exception.RealmsHttpException;
import net.minecraft.client.realms.exception.RealmsServiceException;
import net.minecraft.client.realms.exception.RetryCallException;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.client.realms.util.UploadTokenCache;
import net.minecraft.client.session.Session;
import net.minecraft.util.LenientJsonParser;
import net.minecraft.util.Util;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

@net.fabricmc.api.Environment(EnvType.CLIENT)
public class RealmsClient {
	public static final RealmsClient.Environment ENVIRONMENT = (RealmsClient.Environment)Optional.ofNullable(System.getenv("realms.environment"))
		.or(() -> Optional.ofNullable(System.getProperty("realms.environment")))
		.flatMap(RealmsClient.Environment::fromName)
		.orElse(RealmsClient.Environment.PRODUCTION);
	private static final Logger LOGGER = LogUtils.getLogger();
	@Nullable
	private static volatile RealmsClient instance = null;
	private final CompletableFuture<Set<String>> featureFlagsFuture;
	private final String sessionId;
	private final String username;
	private final MinecraftClient client;
	private static final String WORLDS_ENDPOINT = "worlds";
	private static final String INVITES_ENDPOINT = "invites";
	private static final String MCO_ENDPOINT = "mco";
	private static final String SUBSCRIPTIONS_ENDPOINT = "subscriptions";
	private static final String ACTIVITIES_ENDPOINT = "activities";
	private static final String OPS_ENDPOINT = "ops";
	private static final String PING_STAT_ENDPOINT = "regions/ping/stat";
	private static final String PREFERRED_REGIONS_ENDPOINT = "regions/preferredRegions";
	private static final String TRIAL_ENDPOINT = "trial";
	private static final String NOTIFICATIONS_ENDPOINT = "notifications";
	private static final String FEATURE_ENDPOINT = "feature/v1";
	private static final String LIST_USER_WORLDS_OF_TYPE_ANY_ENDPOINT = "/listUserWorldsOfType/any";
	private static final String CREATE_PRERELEASE_REALM_ENDPOINT = "/$PARENT_WORLD_ID/createPrereleaseRealm";
	private static final String LIST_PRERELEASE_ELIGIBLE_WORLDS_ENDPOINT = "/listPrereleaseEligibleWorlds";
	private static final String WORLD_INITIALIZE_ENDPOINT = "/$WORLD_ID/initialize";
	private static final String WORLD_ENDPOINT = "/$WORLD_ID";
	private static final String LIVEPLAYERLIST_ENDPOINT = "/liveplayerlist";
	private static final String WORLD_ENDPOINT_2 = "/$WORLD_ID";
	private static final String WORLD_PROFILE_ENDPOINT = "/$WORLD_ID/$PROFILE_UUID";
	private static final String MINIGAMES_ENDPOINT = "/minigames/$MINIGAME_ID/$WORLD_ID";
	private static final String AVAILABLE_ENDPOINT = "/available";
	private static final String TEMPLATES_ENDPOINT = "/templates/$WORLD_TYPE";
	private static final String JOIN_PC_ENDPOINT = "/v1/$ID/join/pc";
	private static final String ID_ENDPOINT = "/$ID";
	private static final String WORLD_ENDPOINT_3 = "/$WORLD_ID";
	private static final String INVITE_ENDPOINT = "/$WORLD_ID/invite/$UUID";
	private static final String COUNT_PENDING_ENDPOINT = "/count/pending";
	private static final String PENDING_ENDPOINT = "/pending";
	private static final String ACCEPT_INVITATION_ENDPOINT = "/accept/$INVITATION_ID";
	private static final String REJECT_INVITATION_ENDPOINT = "/reject/$INVITATION_ID";
	private static final String WORLD_ENDPOINT_4 = "/$WORLD_ID";
	private static final String WORLD_CONFIGURATION_ENDPOINT = "/$WORLD_ID/configuration";
	private static final String WORLD_SLOT_ENDPOINT = "/$WORLD_ID/slot/$SLOT_ID";
	private static final String WORLD_OPEN_ENDPOINT = "/$WORLD_ID/open";
	private static final String WORLD_CLOSE_ENDPOINT = "/$WORLD_ID/close";
	private static final String WORLD_RESET_ENDPOINT = "/$WORLD_ID/reset";
	private static final String WORLD_ENDPOINT_6 = "/$WORLD_ID";
	private static final String WORLD_BACKUPS_ENDPOINT = "/$WORLD_ID/backups";
	private static final String WORLD_SLOT_DOWNLOAD_ENDPOINT = "/$WORLD_ID/slot/$SLOT_ID/download";
	private static final String WORLD_BACKUPS_UPLOAD_ENDPOINT = "/$WORLD_ID/backups/upload";
	private static final String CLIENT_COMPATIBLE_ENDPOINT = "/client/compatible";
	private static final String TOS_AGREED_ENDPOINT = "/tos/agreed";
	private static final String NEWS_ENDPOINT = "/v1/news";
	private static final String SEEN_ENDPOINT = "/seen";
	private static final String DISMISS_ENDPOINT = "/dismiss";
	private static final CheckedGson JSON = new CheckedGson();

	public static RealmsClient create() {
		MinecraftClient minecraftClient = MinecraftClient.getInstance();
		return createRealmsClient(minecraftClient);
	}

	public static RealmsClient createRealmsClient(MinecraftClient client) {
		String string = client.getSession().getUsername();
		String string2 = client.getSession().getSessionId();
		RealmsClient realmsClient = instance;
		if (realmsClient != null) {
			return realmsClient;
		} else {
			synchronized (RealmsClient.class) {
				RealmsClient realmsClient2 = instance;
				if (realmsClient2 != null) {
					return realmsClient2;
				} else {
					realmsClient2 = new RealmsClient(string2, string, client);
					instance = realmsClient2;
					return realmsClient2;
				}
			}
		}
	}

	private RealmsClient(String sessionId, String username, MinecraftClient client) {
		this.sessionId = sessionId;
		this.username = username;
		this.client = client;
		RealmsClientConfig.setProxy(client.getNetworkProxy());
		this.featureFlagsFuture = CompletableFuture.supplyAsync(this::fetchFeatureFlags, Util.getDownloadWorkerExecutor());
	}

	public Set<String> getFeatureFlags() {
		return (Set<String>)this.featureFlagsFuture.join();
	}

	private Set<String> fetchFeatureFlags() {
		Session session = MinecraftClient.getInstance().getSession();
		if (session.getAccountType() != Session.AccountType.MSA) {
			return Set.of();
		} else {
			String string = url("feature/v1", null, false);

			try {
				String string2 = this.execute(Request.get(string, 5000, 10000));
				JsonArray jsonArray = LenientJsonParser.parse(string2).getAsJsonArray();
				Set<String> set = (Set<String>)jsonArray.asList().stream().map(JsonElement::getAsString).collect(Collectors.toSet());
				LOGGER.debug("Fetched Realms feature flags: {}", set);
				return set;
			} catch (RealmsServiceException var6) {
				LOGGER.error("Failed to fetch Realms feature flags", (Throwable)var6);
			} catch (Exception var7) {
				LOGGER.error("Could not parse Realms feature flags", (Throwable)var7);
			}

			return Set.of();
		}
	}

	public RealmsServerList listWorlds() throws RealmsServiceException {
		String string = this.url("worlds");
		if (RealmsMainScreen.isSnapshotRealmsEligible()) {
			string = string + "/listUserWorldsOfType/any";
		}

		String string2 = this.execute(Request.get(string));
		return RealmsServerList.parse(JSON, string2);
	}

	public List<RealmsServer> getPrereleaseEligibleServers() throws RealmsServiceException {
		String string = this.url("worlds/listPrereleaseEligibleWorlds");
		String string2 = this.execute(Request.get(string));
		return RealmsServerList.parse(JSON, string2).servers;
	}

	public RealmsServer createPrereleaseServer(Long parentWorldId) throws RealmsServiceException {
		String string = String.valueOf(parentWorldId);
		String string2 = this.url("worlds" + "/$PARENT_WORLD_ID/createPrereleaseRealm".replace("$PARENT_WORLD_ID", string));
		return RealmsServer.parse(JSON, this.execute(Request.post(string2, string)));
	}

	public List<RealmsNotification> listNotifications() throws RealmsServiceException {
		String string = this.url("notifications");
		String string2 = this.execute(Request.get(string));
		return RealmsNotification.parse(string2);
	}

	private static JsonArray toJsonArray(List<UUID> uuids) {
		JsonArray jsonArray = new JsonArray();

		for (UUID uUID : uuids) {
			if (uUID != null) {
				jsonArray.add(uUID.toString());
			}
		}

		return jsonArray;
	}

	public void markNotificationsAsSeen(List<UUID> notifications) throws RealmsServiceException {
		String string = this.url("notifications/seen");
		this.execute(Request.post(string, JSON.toJson(toJsonArray(notifications))));
	}

	public void dismissNotifications(List<UUID> notifications) throws RealmsServiceException {
		String string = this.url("notifications/dismiss");
		this.execute(Request.post(string, JSON.toJson(toJsonArray(notifications))));
	}

	public RealmsServer getOwnWorld(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$ID".replace("$ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.get(string));
		return RealmsServer.parse(JSON, string2);
	}

	public RealmsRegionDataList getRegionDataList() throws RealmsServiceException {
		String string = this.url("regions/preferredRegions");
		String string2 = this.execute(Request.get(string));

		try {
			RealmsRegionDataList realmsRegionDataList = JSON.fromJson(string2, RealmsRegionDataList.class);
			if (realmsRegionDataList == null) {
				return RealmsRegionDataList.empty();
			} else {
				Set<RealmsRegion> set = (Set<RealmsRegion>)realmsRegionDataList.regionData().stream().map(RegionData::region).collect(Collectors.toSet());

				for (RealmsRegion realmsRegion : RealmsRegion.values()) {
					if (realmsRegion != RealmsRegion.INVALID_REGION && !set.contains(realmsRegion)) {
						LOGGER.debug("No realms region matching {} in server response", realmsRegion);
					}
				}

				return realmsRegionDataList;
			}
		} catch (Exception var9) {
			LOGGER.error("Could not parse PreferredRegionSelections: {}", var9.getMessage());
			return RealmsRegionDataList.empty();
		}
	}

	public PlayerActivities getPlayerActivities(long worldId) throws RealmsServiceException {
		String string = this.url("activities" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.get(string));
		return PlayerActivities.parse(string2);
	}

	public RealmsServerPlayerList getLiveStats() throws RealmsServiceException {
		String string = this.url("activities/liveplayerlist");
		String string2 = this.execute(Request.get(string));
		return RealmsServerPlayerList.parse(string2);
	}

	public RealmsServerAddress join(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/v1/$ID/join/pc".replace("$ID", worldId + ""));
		String string2 = this.execute(Request.get(string, 5000, 30000));
		return RealmsServerAddress.parse(JSON, string2);
	}

	public void initializeWorld(long worldId, String name, String motd) throws RealmsServiceException {
		RealmsDescriptionDto realmsDescriptionDto = new RealmsDescriptionDto(name, motd);
		String string = this.url("worlds" + "/$WORLD_ID/initialize".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = JSON.toJson(realmsDescriptionDto);
		this.execute(Request.post(string, string2, 5000, 10000));
	}

	public boolean mcoEnabled() throws RealmsServiceException {
		String string = this.url("mco/available");
		String string2 = this.execute(Request.get(string));
		return Boolean.parseBoolean(string2);
	}

	public RealmsClient.CompatibleVersionResponse clientCompatible() throws RealmsServiceException {
		String string = this.url("mco/client/compatible");
		String string2 = this.execute(Request.get(string));

		try {
			return RealmsClient.CompatibleVersionResponse.valueOf(string2);
		} catch (IllegalArgumentException var5) {
			throw new RealmsServiceException(RealmsError.SimpleHttpError.unknownCompatibility(string2));
		}
	}

	public void uninvite(long worldId, UUID profileUuid) throws RealmsServiceException {
		String string = this.url(
			"invites" + "/$WORLD_ID/invite/$UUID".replace("$WORLD_ID", String.valueOf(worldId)).replace("$UUID", UndashedUuid.toString(profileUuid))
		);
		this.execute(Request.delete(string));
	}

	public void uninviteMyselfFrom(long worldId) throws RealmsServiceException {
		String string = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(worldId)));
		this.execute(Request.delete(string));
	}

	public List<PlayerInfo> invite(long worldId, String profileName) throws RealmsServiceException {
		PlayerInfo playerInfo = new PlayerInfo();
		playerInfo.setName(profileName);
		String string = this.url("invites" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.post(string, JSON.toJson(playerInfo)));
		return RealmsServer.parse(JSON, string2).players;
	}

	public BackupList backupsFor(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.get(string));
		return BackupList.parse(string2);
	}

	public void configure(
		long worldId,
		String name,
		String description,
		@Nullable RealmsRegionSelectionPreference regionSelectionPreference,
		int slotId,
		RealmsWorldOptions options,
		List<RealmsSettingDto> settings
	) throws RealmsServiceException {
		RealmsRegionSelectionPreference realmsRegionSelectionPreference = regionSelectionPreference != null
			? regionSelectionPreference
			: new RealmsRegionSelectionPreference(RegionSelectionMethod.DEFAULT, null);
		RealmsDescriptionDto realmsDescriptionDto = new RealmsDescriptionDto(name, description);
		RealmsOptionsDto realmsOptionsDto = new RealmsOptionsDto(slotId, options, RealmsSettingDto.isHardcore(settings));
		RealmsConfigurationDto realmsConfigurationDto = new RealmsConfigurationDto(realmsOptionsDto, settings, realmsRegionSelectionPreference, realmsDescriptionDto);
		String string = this.url("worlds" + "/$WORLD_ID/configuration".replace("$WORLD_ID", String.valueOf(worldId)));
		this.execute(Request.post(string, JSON.toJson(realmsConfigurationDto)));
	}

	public void updateSlot(long worldId, int slot, RealmsWorldOptions options, List<RealmsSettingDto> settings) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(worldId)).replace("$SLOT_ID", String.valueOf(slot)));
		String string2 = JSON.toJson(new RealmsOptionsDto(slot, options, RealmsSettingDto.isHardcore(settings)));
		this.execute(Request.post(string, string2));
	}

	public boolean switchSlot(long worldId, int slot) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/slot/$SLOT_ID".replace("$WORLD_ID", String.valueOf(worldId)).replace("$SLOT_ID", String.valueOf(slot)));
		String string2 = this.execute(Request.put(string, ""));
		return Boolean.valueOf(string2);
	}

	public void restoreWorld(long worldId, String backupId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/backups".replace("$WORLD_ID", String.valueOf(worldId)), "backupId=" + backupId);
		this.execute(Request.put(string, "", 40000, 600000));
	}

	public WorldTemplatePaginatedList fetchWorldTemplates(int page, int pageSize, RealmsServer.WorldType type) throws RealmsServiceException {
		String string = this.url(
			"worlds" + "/templates/$WORLD_TYPE".replace("$WORLD_TYPE", type.toString()), String.format(Locale.ROOT, "page=%d&pageSize=%d", page, pageSize)
		);
		String string2 = this.execute(Request.get(string));
		return WorldTemplatePaginatedList.parse(string2);
	}

	public Boolean putIntoMinigameMode(long worldId, String minigameId) throws RealmsServiceException {
		String string = "/minigames/$MINIGAME_ID/$WORLD_ID".replace("$MINIGAME_ID", minigameId).replace("$WORLD_ID", String.valueOf(worldId));
		String string2 = this.url("worlds" + string);
		return Boolean.valueOf(this.execute(Request.put(string2, "")));
	}

	public Ops op(long worldId, UUID profileUuid) throws RealmsServiceException {
		String string = "/$WORLD_ID/$PROFILE_UUID".replace("$WORLD_ID", String.valueOf(worldId)).replace("$PROFILE_UUID", UndashedUuid.toString(profileUuid));
		String string2 = this.url("ops" + string);
		return Ops.parse(this.execute(Request.post(string2, "")));
	}

	public Ops deop(long worldId, UUID profileUuid) throws RealmsServiceException {
		String string = "/$WORLD_ID/$PROFILE_UUID".replace("$WORLD_ID", String.valueOf(worldId)).replace("$PROFILE_UUID", UndashedUuid.toString(profileUuid));
		String string2 = this.url("ops" + string);
		return Ops.parse(this.execute(Request.delete(string2)));
	}

	public Boolean open(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/open".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.put(string, ""));
		return Boolean.valueOf(string2);
	}

	public Boolean close(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/close".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.put(string, ""));
		return Boolean.valueOf(string2);
	}

	public Boolean resetWorldWithTemplate(long worldId, String worldTemplateId) throws RealmsServiceException {
		RealmsWorldResetDto realmsWorldResetDto = new RealmsWorldResetDto(null, Long.valueOf(worldTemplateId), -1, false, Set.of());
		String string = this.url("worlds" + "/$WORLD_ID/reset".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.post(string, JSON.toJson(realmsWorldResetDto), 30000, 80000));
		return Boolean.valueOf(string2);
	}

	public Subscription subscriptionFor(long worldId) throws RealmsServiceException {
		String string = this.url("subscriptions" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = this.execute(Request.get(string));
		return Subscription.parse(string2);
	}

	public int pendingInvitesCount() throws RealmsServiceException {
		return this.pendingInvites().pendingInvites.size();
	}

	public PendingInvitesList pendingInvites() throws RealmsServiceException {
		String string = this.url("invites/pending");
		String string2 = this.execute(Request.get(string));
		PendingInvitesList pendingInvitesList = PendingInvitesList.parse(string2);
		pendingInvitesList.pendingInvites.removeIf(this::isOwnerBlocked);
		return pendingInvitesList;
	}

	private boolean isOwnerBlocked(PendingInvite invite) {
		return this.client.getSocialInteractionsManager().isPlayerBlocked(invite.worldOwnerUuid);
	}

	public void acceptInvitation(String invitationId) throws RealmsServiceException {
		String string = this.url("invites" + "/accept/$INVITATION_ID".replace("$INVITATION_ID", invitationId));
		this.execute(Request.put(string, ""));
	}

	public WorldDownload download(long worldId, int slotId) throws RealmsServiceException {
		String string = this.url(
			"worlds" + "/$WORLD_ID/slot/$SLOT_ID/download".replace("$WORLD_ID", String.valueOf(worldId)).replace("$SLOT_ID", String.valueOf(slotId))
		);
		String string2 = this.execute(Request.get(string));
		return WorldDownload.parse(string2);
	}

	@Nullable
	public UploadInfo upload(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID/backups/upload".replace("$WORLD_ID", String.valueOf(worldId)));
		String string2 = UploadTokenCache.get(worldId);
		UploadInfo uploadInfo = UploadInfo.parse(this.execute(Request.put(string, UploadInfo.createRequestContent(string2))));
		if (uploadInfo != null) {
			UploadTokenCache.put(worldId, uploadInfo.getToken());
		}

		return uploadInfo;
	}

	public void rejectInvitation(String invitationId) throws RealmsServiceException {
		String string = this.url("invites" + "/reject/$INVITATION_ID".replace("$INVITATION_ID", invitationId));
		this.execute(Request.put(string, ""));
	}

	public void agreeToTos() throws RealmsServiceException {
		String string = this.url("mco/tos/agreed");
		this.execute(Request.post(string, ""));
	}

	public RealmsNews getNews() throws RealmsServiceException {
		String string = this.url("mco/v1/news");
		String string2 = this.execute(Request.get(string, 5000, 10000));
		return RealmsNews.parse(string2);
	}

	public void sendPingResults(PingResult pingResult) throws RealmsServiceException {
		String string = this.url("regions/ping/stat");
		this.execute(Request.post(string, JSON.toJson(pingResult)));
	}

	public Boolean trialAvailable() throws RealmsServiceException {
		String string = this.url("trial");
		String string2 = this.execute(Request.get(string));
		return Boolean.valueOf(string2);
	}

	public void deleteWorld(long worldId) throws RealmsServiceException {
		String string = this.url("worlds" + "/$WORLD_ID".replace("$WORLD_ID", String.valueOf(worldId)));
		this.execute(Request.delete(string));
	}

	private String url(String path) throws RealmsServiceException {
		return this.url(path, null);
	}

	private String url(String path, @Nullable String queryString) throws RealmsServiceException {
		return url(path, queryString, this.getFeatureFlags().contains("realms_in_aks"));
	}

	private static String url(String path, @Nullable String queryString, boolean aks) {
		try {
			return new URI(ENVIRONMENT.protocol, aks ? ENVIRONMENT.aksUrl : ENVIRONMENT.baseUrl, "/" + path, queryString, null).toASCIIString();
		} catch (URISyntaxException var4) {
			throw new IllegalArgumentException(path, var4);
		}
	}

	private String execute(Request<?> r) throws RealmsServiceException {
		r.cookie("sid", this.sessionId);
		r.cookie("user", this.username);
		r.cookie("version", SharedConstants.getGameVersion().name());
		r.prerelease(RealmsMainScreen.isSnapshotRealmsEligible());

		try {
			int i = r.responseCode();
			if (i != 503 && i != 277) {
				String string = r.text();
				if (i >= 200 && i < 300) {
					return string;
				} else if (i == 401) {
					String string2 = r.getHeader("WWW-Authenticate");
					LOGGER.info("Could not authorize you against Realms server: {}", string2);
					throw new RealmsServiceException(new RealmsError.AuthenticationError(string2));
				} else {
					String string2 = r.connection.getContentType();
					if (string2 != null && string2.startsWith("text/html")) {
						throw new RealmsServiceException(RealmsError.SimpleHttpError.unreadableHtmlBody(i, string));
					} else {
						RealmsError realmsError = RealmsError.ofHttp(i, string);
						throw new RealmsServiceException(realmsError);
					}
				}
			} else {
				int j = r.getRetryAfterHeader();
				throw new RetryCallException(j, i);
			}
		} catch (RealmsHttpException var6) {
			throw new RealmsServiceException(RealmsError.SimpleHttpError.connectivity(var6));
		}
	}

	@net.fabricmc.api.Environment(EnvType.CLIENT)
	public static enum CompatibleVersionResponse {
		COMPATIBLE,
		OUTDATED,
		OTHER;
	}

	@net.fabricmc.api.Environment(EnvType.CLIENT)
	public static enum Environment {
		PRODUCTION("pc.realms.minecraft.net", "java.frontendlegacy.realms.minecraft-services.net", "https"),
		STAGE("pc-stage.realms.minecraft.net", "java.frontendlegacy.stage-c2a40e62.realms.minecraft-services.net", "https"),
		LOCAL("localhost:8080", "localhost:8080", "http");

		public final String baseUrl;
		public final String aksUrl;
		public final String protocol;

		private Environment(final String baseUrl, final String aksUrl, final String protocol) {
			this.baseUrl = baseUrl;
			this.aksUrl = aksUrl;
			this.protocol = protocol;
		}

		public static Optional<RealmsClient.Environment> fromName(String name) {
			String var1 = name.toLowerCase(Locale.ROOT);

			return switch (var1) {
				case "production" -> Optional.of(PRODUCTION);
				case "local" -> Optional.of(LOCAL);
				case "stage", "staging" -> Optional.of(STAGE);
				default -> Optional.empty();
			};
		}
	}
}
